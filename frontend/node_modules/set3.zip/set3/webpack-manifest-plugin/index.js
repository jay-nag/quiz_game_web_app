module.exports = require('./lib/plugin')
