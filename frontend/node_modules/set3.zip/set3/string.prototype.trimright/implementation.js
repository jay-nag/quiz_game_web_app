'use strict';

module.exports = require('string.prototype.trimend/implementation');
