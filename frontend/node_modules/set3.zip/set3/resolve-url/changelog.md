### Version 0.2.1 (2014-02-25) ###

- Fix edge case when (accidentally) supplying only one argument, and that
  argument happens to be a falsy value such as `undefined` or `null`.


### Version 0.2.0 (2014-02-24) ###

- Disallow passing 0 arguments. It’s weird and inconsistent between browsers.
  (Backwards incompatible change.)


### Version 0.1.0 (2014-02-23) ###

- Initial release.
