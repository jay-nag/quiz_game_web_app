"use strict";

var isImplemented = require("../../../math/sign/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
