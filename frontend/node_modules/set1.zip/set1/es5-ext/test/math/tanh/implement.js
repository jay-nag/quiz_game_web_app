"use strict";

var isImplemented = require("../../../math/tanh/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
