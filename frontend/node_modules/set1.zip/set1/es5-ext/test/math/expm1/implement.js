"use strict";

var isImplemented = require("../../../math/expm1/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
