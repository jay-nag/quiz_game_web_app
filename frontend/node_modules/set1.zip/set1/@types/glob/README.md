# Installation
> `npm install --save @types/glob`

# Summary
This package contains type definitions for Glob (https://github.com/isaacs/node-glob).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/glob

Additional Details
 * Last updated: Thu, 27 Sep 2018 12:34:19 GMT
 * Dependencies: events, minimatch, node
 * Global values: none

# Credits
These definitions were written by vvakame <https://github.com/vvakame>, voy <https://github.com/voy>, Klaus Meinhardt <https://github.com/ajafff>.
