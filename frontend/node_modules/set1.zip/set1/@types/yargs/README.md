# Installation
> `npm install --save @types/yargs`

# Summary
This package contains type definitions for yargs (https://github.com/chevex/yargs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yargs/v13.

### Additional Details
 * Last updated: Fri, 31 Jan 2020 23:40:19 GMT
 * Dependencies: [@types/yargs-parser](https://npmjs.com/package/@types/yargs-parser)
 * Global values: none

# Credits
These definitions were written by Martin Poelstra (https://github.com/poelstra), Mizunashi Mana (https://github.com/mizunashi-mana), Jeffery Grajkowski (https://github.com/pushplay), Jeff Kenney (https://github.com/jeffkenney), Jimi (Dimitris) Charalampidis (https://github.com/JimiC), Steffen Viken Valvåg (https://github.com/steffenvv), Emily Marigold Klassen (https://github.com/forivall), and ExE Boss (https://github.com/ExE-Boss).
