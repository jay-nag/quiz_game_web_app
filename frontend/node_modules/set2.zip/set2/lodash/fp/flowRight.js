var convert = require('./convert'),
    func = convert('flowRight', require('../flowRight'));

func.placeholder = require('./placeholder');
module.exports = func;
