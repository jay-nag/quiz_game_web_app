var convert = require('./convert'),
    func = convert('assignAllWith', require('../assignWith'));

func.placeholder = require('./placeholder');
module.exports = func;
